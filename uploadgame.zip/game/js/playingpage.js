

function input(b_name) {
    var box= document.getElementById(b_name);
    {
        console.log(b_name);
    var req=new XMLHttpRequest();
    req.open("get","playingupdate.php?boxid="+b_name,true);
    req.send();
    req.onreadystatechange=function(){

        if(req.readyState==4 &&req.status==200)
        {

            var req2=new XMLHttpRequest();
            req2.open("get","onupdated.php",true);
            req2.send();
            req2.onreadystatechange=function () {
                if(req2.readyState==4 && req2.status==200)
                {
                   var bs= document.getElementById("bs");
                   bs.innerHTML=req2.responseText;
                }
                
            };

        }

    };
}
}


function onetimecheck(){
    var req1=new XMLHttpRequest();
    req1.open("get","onupdated.php",true);
    req1.send();
    req1.onreadystatechange=function () {
        if(req1.readyState==4 && req1.status==200)
        {
           var bs= document.getElementById("bs");
           bs.innerHTML=req1.responseText;
        }
        
    };
}




onetimecheck();






function myfun()
{
   setInterval(onetimecheck,2000);
}

myfun();