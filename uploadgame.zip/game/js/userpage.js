
function req(su,ru)
{
    var senderuser=su;
    var receveruser=ru;

    var a= document.getElementById(ru);
            a.className="btn btn-success disabled"
            a.innerHTML="Processing...";

    var req=new XMLHttpRequest();
    req.open("get","request.php?senderuser="+senderuser+"&receveruser="+receveruser,true);
    req.send();
    req.onreadystatechange=function(){
        if(req.readyState==4 && req.status==200)
        {
            if(req.responseText=="yes")
            {
                window.location="playing.php";
            }
            else if(req.responseText=="no")
            {
                var btn= document.getElementById(ru);
                btn.className="btn btn-success disabled ";
                btn.innerHTML="Can't play";
            }
            
        }
    };

}
function getreq() {
    var req2=new XMLHttpRequest();
    req2.open("get","getrequest.php?senderuser="+senderuser,true);
    req2.send();
    req2.onreadystatechange=function(){
        if(req2.readyState==4 && req2.status==200)
        {
            if(req2.responseText=="0")
            {
                  setTimeout('getreq()',500);
            }
            else
            {
                if (confirm(req2.responseText)) {
                    var req3=new XMLHttpRequest();
                    req3.open("get","respoonreq.php?reseveruser="+senderuser,true);
                    req3.send();
                    req3.onreadystatechange=function(){
                        if(req3.readyState==4 && req3.status==200)
                        {
                            window.location="playing.php";
                        }
                    };
                } 
                else {

                   
        
                }
            }
            
        }
    }
}

getreq();



