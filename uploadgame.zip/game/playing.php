<?php

session_start();

if( !isset($_SESSION['username']) || !isset($_SESSION['password']) )
{
    header('location:index.html');
}

$username=$_SESSION['username'];
$password=$_SESSION['password'];

$con=mysqli_connect('localhost','id4760458_indra','Indra@123');
mysqli_select_db($con,'id4760458_ttt');

$q1="select id,smb,playingtn,photo from users where name='$username' and password='$password' ";
$r=mysqli_query($con,$q1);
$rindex=mysqli_fetch_array($r);
$playingtn=$rindex['playingtn'];
$id=$rindex['id'];
$mypic=$rindex['photo'];

$q3="select isupdated,user_turn,ut1,ut2 from playing where tablename='$playingtn' ";
$lstud=mysqli_query($con,$q3);
$lstudindex=mysqli_fetch_array($lstud);
$lastupdate=$lstudindex['isupdated'];
$ut1=$lstudindex['ut1'];
$ut2=$lstudindex['ut2'];


?>
<script>
   var lastupdate= <?php echo $lastupdate ?> ;
</script>



<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="css/playingpage.css">
</head>
<body>
    

<div class="container-fluid">


<header>
            <nav class="navbar navbar-expand navbar-dark bg-dark">
                    <a class="navbar-brand ttt" href="">Tic-Tac-Toe</a>
                    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                      <span class="navbar-toggler-icon"></span>
                    </button>
                  
                    <div class="collapse navbar-collapse" id="navbarSupportedContent">
                      <ul class="navbar-nav ">
                        
                        <li class="nav-item dropdown">
                          <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                            Contect-Us
                          </a>
                          <div class="dropdown-menu" aria-labelledby="navbarDropdown">
                            <a class="dropdown-item" href="">8770734350</a>
                            <div class="dropdown-divider"></div>
                            <a class="dropdown-item" href="">indrakumarmhasi@gmail.com</a>
                          </div>                            
                        </li>
                      </ul>                      
                    </div>
                    <a class="navbar-brand" href="logout.php">LogOut</a>
                    
                  </nav>
    </header>


    <header class="header mt-3 bg-info pb-1">
            <div class="text-center">
                <h2>Enjoy The Game</h2>
            </div>
    </header>

    <section class="game-container mt-2">       <!-- Sction for game -->
       <div class="row" id="bs">
         
       </div>
    </section>

    
    <hr>
<h3 class="text-center">Compitition</h3>
<div class="imgsec row">

<div class="mypic col-md-4 col-sm-12">

<?php
echo '<img style="height:200px; width:200px;" class="img-thumbnail img-fluid" alt="Profile Image" src="data:image/jpeg;base64,'.base64_encode( $rindex['photo'] ).'"/>';
?>

</div>
<div class="vs col-md-4 col-sm-12">
<h2 class="text-secondary text-center"> <?php echo $username ?> </h2>


<?php
    if($id==$ut1)
{
      $qforname="select name,photo from users where id=$ut2";
      $namearr=mysqli_query($con,$qforname);
      $nameindex=mysqli_fetch_array($namearr);
      $name=$nameindex['name'];
      
?>
  
      <h3 class="text-center ">Vs. </h3>
      <br>
      <h2 class="text-secondary text-center"> <?php echo $name ?> </h2>
      </div>
<div class="col-md-4 col-sm-12">
<?php
 echo '<img style="height:200px; width:200px;" class="img-thumbnail float-right img-fluid" alt="Profile Image" src="data:image/jpeg;base64,'.base64_encode( $nameindex['photo'] ).'"/>';
 ?>
 </div>
<?php
}
else{
      $qforname="select name,photo from users where id=$ut1";
      $namearr=mysqli_query($con,$qforname);
      $nameindex=mysqli_fetch_array($namearr);
      $name=$nameindex['name'];
?>
      <h3 class="text-center ">Vs.</h3>

      <br>
      <h2 class="text-secondary text-center"> <?php echo $name ?> </h2>
</div>
<div class="col-md-4 col-sm-12">
    
<?php
   echo '<img style="height:200px; width:200px;" class="img-thumbnail float-right img-fluid" alt="Profile Image" src="data:image/jpeg;base64,'.base64_encode( $nameindex['photo'] ).'"/>';
    
}

?>
</div>

</div>



    <hr>
    <section class="about-game">
        <div class=" about-text-cont">
           <h3 class="text-uppercase">About game</h3>
           <p class="lead">
               This is a simple tic-tac-toe game where you two players
               can play simultaneously, you just have to click on boxex 
               whenever there is your turn and wait whenever the next player is 
               playing , player who will first mark any three continues boxes 
               will win the game, so lets enjoy this very interesting game with 
               your partner player.
           </p>
        </div>

    </section>


    <section class="bg-dark text-center pt-5" >

<div class="col-md-3 mt-2" style="display: inline-block">
    <a href="https://www.linkedin.com/in/indra-kumar-mhaski-15055714a" style="color: rgb(0, 250, 187)"> <i class="fa fa-4x fa-linkedin"></i> </a>

</div>
<div class="col-md-3 mt-2" style="display: inline-block">
    <a href="https://twitter.com/Indra_Kr_Mhaski" style="color: rgb(0, 250, 187)"> <i class="fa fa-4x fa-twitter"></i> </a>
</div>

<div class="col-md-3 mt-2" style="display: inline-block">
    <a href="https://github.com/indrakumarmhaski" style="color: rgb(0, 250, 187)"> <i class="fa fa-4x fa-github"></i> </a>
  </div>
<div class="col-md-2 mt-2" style="display: inline-block">
      <a href="https://codepen.io/Indra_Kr_Mhaski/" style="color: rgb(0, 250, 187)"> <i class="fa fa-4x fa-codepen"></i> </a>
</div>

</section>


<footer class="footer bg-dark">

  <blockquote class="blockquote text-left">
    
          <p class="text-right pt-3" style="color: rgb(0, 250, 154)">&copy; 2018 Er. Indra Kumar Mhaski.</p>
          <hr>
          <p class="mb-0" style="color: rgb(0, 250, 154)">This site is developed and maintained by:
              <cite title="Source Title">Er.
                  Indra Kumar Mhaski.
              </cite>
          </p>
      </blockquote>

</footer>

</div>







     <script src="js/playingpage.js"></script>
    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
     
</body>
</html>