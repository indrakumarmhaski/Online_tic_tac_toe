<?php

session_start();

$senderuser=intval($_GET['senderuser']);
$receveruser=intval($_GET['receveruser']);



$con=mysqli_connect('localhost','id4760458_indra','Indra@123');
mysqli_select_db($con,'id4760458_ttt');

$tablename=$_GET['receveruser'].$_GET['senderuser'];
$q="update users set play_req=1,sender=$senderuser,smb='X',playingtn='$tablename' where id=$receveruser ";
mysqli_query($con,$q);

$qu="update users set playingtn='$tablename',smb='0',response='yes',sender=$senderuser where id=$senderuser" ;
mysqli_query($con,$qu);
$q1="select user_turn from playing where tablename='$tablename' ";
$isexist=mysqli_query($con,$q1);
$nor=mysqli_num_rows($isexist);
if($nor==1)
{

}
else
{
    $q2="insert into playing (tablename,user_turn) values ('$tablename',$senderuser) ";
    mysqli_query($con,$q2);
    $q3="update playing set ut1=$senderuser,ut2=$receveruser where tablename='$tablename' ";
    mysqli_query($con,$q3);
}


sleep(15);

$res="select response from users where id=$receveruser";
$resobj=mysqli_query($con,$res);
$response=mysqli_fetch_array($resobj);
if($response['response']=='yes')
{
    echo 'yes';
}
else
{
    echo 'no';
}


?>
