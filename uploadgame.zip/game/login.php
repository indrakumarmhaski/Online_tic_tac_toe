<?php

session_start();

$username=$_POST['username'];
$password=$_POST['password'];

$con=mysqli_connect('localhost','id4760458_indra','Indra@123');
mysqli_select_db($con,'id4760458_ttt');

$q="select name,password from users where name='$username' and password='$password' ";

$result=mysqli_query($con,$q);

$num=mysqli_num_rows($result);

if($num==1)
{
    $_SESSION['username']=$username;
    $_SESSION['password']=$password;
    $ison="update users set isonline=1 where name='$username' and password='$password' ";
    mysqli_query($con,$ison);
    header('location:userpage.php');
}
else{
    header('location:upnotexists.php');
}

mysqli_close($con);

?>
