<?php

session_start();

$username=$_SESSION['username'];
$password=$_SESSION['password'];

$con=mysqli_connect('localhost','id4760458_indra','Indra@123');
mysqli_select_db($con,'id4760458_ttt');

$q1="select id,smb,playingtn from users where name='$username' and password='$password' ";
$r=mysqli_query($con,$q1);
$rindex=mysqli_fetch_array($r);
$id=$rindex['id'];
$smb=$rindex['smb'];
$playingtn=$rindex['playingtn'];

$q2="select user_turn,b1,b2,b3,b4,b5,b6,b7,b8,b9 from playing where tablename='$playingtn' ";
$re=mysqli_query($con,$q2);
$arr=mysqli_fetch_array($re);
$user_turn=$arr['user_turn'];
$b1=$arr['b1'];
$b2=$arr['b2'];
$b3=$arr['b3'];
$b4=$arr['b4'];
$b5=$arr['b5'];
$b6=$arr['b6'];
$b7=$arr['b7'];
$b8=$arr['b8'];
$b9=$arr['b9'];


// We are writing for winning conditions the function.

if($smb=='X')
{
      $nextpsimb='0';
}
else
{
      $nextpsimb='X';
}

function checkforwinner()
{
      // if i win then return 1 , next pla. win return 2 not so return 0
      global $smb,$nextpsimb;
      global $b1,$b2,$b3,$b4,$b5,$b6,$b7,$b8,$b9;

      if($b1==$smb && $b4==$smb && $b7==$smb)
      {
         return 1;
      }
      else if($b1==$smb && $b2==$smb && $b3==$smb)
      {
          return 1;
      }
      else if($b3==$smb && $b6==$smb && $b9==$smb)
      {
          return 1;
      }
      else if($b4==$smb && $b5==$smb && $b6==$smb)
      {
          return 1;
      }
      else if($b1==$smb && $b5==$smb && $b9==$smb)
      {
          return 1;
      }
      else if($b3==$smb && $b5==$smb && $b7==$smb)
      {
          return 1;
      }
      else if($b2==$smb && $b5==$smb && $b8==$smb)
      {
          return 1;
      }

// Conditions for next player

else if($b1==$nextpsimb && $b4==$nextpsimb && $b7==$nextpsimb)
    {
       return 2;
    }
    else if($b1==$nextpsimb && $b2==$nextpsimb && $b3==$nextpsimb)
    {
        return 2;
    }
    else if($b3==$nextpsimb && $b6==$nextpsimb && $b9==$nextpsimb)
    {
        return 2;
    }
    else if($b4==$nextpsimb && $b5==$nextpsimb && $b6==$nextpsimb)
    {
        return 2;
    }
    else if($b1==$nextpsimb && $b5==$nextpsimb && $b9==$nextpsimb)
    {
        return 2;
    }
    else if($b3==$nextpsimb && $b5==$nextpsimb && $b7==$nextpsimb)
    {
        return 2;
    }
    else if($b2==$nextpsimb && $b5==$nextpsimb && $b8==$nextpsimb)
    {
        return 2;
    }
    else 
    {
          return 0;
    }

      
}      //The end of our function.


$winner=checkforwinner();

if($winner==1)
{
?>
     <div class="col-md-12 col-sm-12 bg-danger text-center">
        <h3>you win the match</h3>
        <br>
        <h1>LogOut to play again</h1>
     </div>
<?php
}
elseif($winner==2)
{
?>
      <div class="col-md-12 col-sm-12 bg-danger text-center">
        <h3>Next Player win the match</h3>
        <br>
        <h1>LogOut to play again</h1>
     </div>
<?php   
}

else
{
?>

      <div class="col-md-12 col-sm-12 bg-success text-center">
        <h3>Your Simbol: <?php echo $smb ?></h3>
     </div>
     
  
<div class="col-md-4 text-center">
<?php

if($user_turn==$id)
{
?>
       <h2 class="mt-5 first-user d-none d-sm-block" id="u1">This Your turn</h2>
<?php
}
else
{
?>
       <h2 class="mt-5 first-user d-none d-sm-block" id="u1">Wait...</h2>
<?php
}
?>
</div>

<div class="col-md-4 text-center mt-2 "  >  <!-- Boxes sec -->
<?php

if($user_turn==$id)
{
         if($arr['b1']=='$')
         {
   ?>

         <div class="game-box-a text-center" id="b1" onclick="input('b1')">
            $
         </div>
  <?php        
          }
         else if($arr['b1']=='X') 
          {
   ?>  
         <div class="game-box-b text-center" id="b1" >
            X
          </div>
   <?php
          }
         else if($arr['b1']=='0')
          {
    ?>
         <div class="game-box-c text-center" id="b1" >
            0
         </div>
   <?php
         }
         if($arr['b2']=='$')
         {
   ?>

         <div class="game-box-a text-center" id="b1" onclick="input('b2')">
            $
         </div>
  <?php        
          }
         else if($arr['b2']=='X') 
          {
   ?>  
         <div class="game-box-b text-center" id="b2" >
            X
          </div>
   <?php
          }
         else if($arr['b2']=='0')
          {
    ?>
         <div class="game-box-c text-center" id="b2" >
            0
         </div>
   <?php
         }
        
         if($arr['b3']=='$')
         {
   ?>
   
         <div class="game-box-a text-center" id="b3" onclick="input('b3')">
            $
         </div>
         <br>
   <?php        
          }
         else if($arr['b3']=='X') 
          {
   ?>  
         <div class="game-box-b text-center" id="b3" >
            X
          </div>
          <br>
   <?php
          }
         else if($arr['b3']=='0')
          {
    ?>
         <div class="game-box-c text-center" id="b3" >
            0
         </div>
   
         <br>
   <?php
         }
   
         // For b4
         if($arr['b4']=='$')
         {
   ?>
   
         <div class="game-box-a text-center" id="b4" onclick="input('b4')">
            $
         </div>
   <?php        
          }
         else if($arr['b4']=='X') 
          {
   ?>  
         <div class="game-box-b text-center" id="b4" >
            X
          </div>
   <?php
          }
         else if($arr['b4']=='0')
          {
    ?>
         <div class="game-box-c text-center" id="b4" >
            0
         </div>
   <?php
         }
         // for b5
         if($arr['b5']=='$')
         {
   ?>
   
         <div class="game-box-a text-center" id="b5" onclick="input('b5')">
            $
         </div>
   <?php        
          }
         else if($arr['b5']=='X') 
          {
   ?>  
         <div class="game-box-b text-center" id="b5" >
            X
          </div>
   <?php
          }
         else if($arr['b5']=='0')
          {
    ?>
         <div class="game-box-c text-center" id="b5" >
            0
         </div>
   <?php
         }
   
         // for b6
         if($arr['b6']=='$')
         {
   ?>
   
         <div class="game-box-a text-center" id="b6" onclick="input('b6')">
            $
         </div>
         <br>
   <?php        
          }
         else if($arr['b6']=='X') 
          {
   ?>  
         <div class="game-box-b text-center" id="b6" >
            X
          </div>
          <br>
   <?php
          }
         else if($arr['b6']=='0')
          {
    ?>
         <div class="game-box-c text-center" id="b6" >
            0
         </div>
         <br>
   <?php
         }
         // for b7
         if($arr['b7']=='$')
         {
   ?>
   
         <div class="game-box-a text-center" id="b7" onclick="input('b7')">
            $
         </div>
   <?php        
          }
         else if($arr['b7']=='X') 
          {
   ?>  
         <div class="game-box-b text-center" id="b7" >
            X
          </div>
   <?php
          }
         else if($arr['b7']=='0')
          {
    ?>
         <div class="game-box-c text-center" id="b7" >
            0
         </div>
   <?php
         }
         // for b8
         if($arr['b8']=='$')
         {
   ?>
   
         <div class="game-box-a text-center" id="b8" onclick="input('b8')">
            $
         </div>
   <?php        
          }
         else if($arr['b8']=='X') 
          {
   ?>  
         <div class="game-box-b text-center" id="b8" >
            X
          </div>
   <?php
          }
         else if($arr['b8']=='0')
          {
    ?>
         <div class="game-box-c text-center" id="b8" >
            0
         </div>
   <?php
         }
         // for b9
         if($arr['b9']=='$')
         {
   ?>
   
         <div class="game-box-a text-center" id="b9" onclick="input('b9')">
            $
         </div>
         <br>
   <?php        
          }
         else if($arr['b9']=='X') 
          {
   ?>  
         <div class="game-box-b text-center" id="b9" >
            X
          </div>
          <br>
   <?php
          }
         else if($arr['b9']=='0')
          {
    ?>
         <div class="game-box-c text-center" id="b9" >
            0
         </div>
         <br>
   <?php
         }
} 
else
{
       
      if($arr['b1']=='$')
         {
   ?>

         <div class="game-box-a text-center" id="b1" >
            $
         </div>
  <?php        
          }
         else if($arr['b1']=='X') 
          {
   ?>  
         <div class="game-box-b text-center" id="b1" >
            X
          </div>
   <?php
          }
         else if($arr['b1']=='0')
          {
    ?>
         <div class="game-box-c text-center" id="b1" >
            0
         </div>
   <?php
         }

      //    for b2
      if($arr['b2']=='$')
      {
?>

      <div class="game-box-a text-center" id="b2" >
         $
      </div>
<?php        
       }
      else if($arr['b2']=='X') 
       {
?>  
      <div class="game-box-b text-center" id="b2" >
         X
       </div>
<?php
       }
      else if($arr['b2']=='0')
       {
 ?>
      <div class="game-box-c text-center" id="b2" >
         0
      </div>
<?php
      }
      //    for b3
      if($arr['b3']=='$')
      {
?>

      <div class="game-box-a text-center" id="b3" >
         $
      </div>
      <br>
<?php        
       }
      else if($arr['b3']=='X') 
       {
?>  
      <div class="game-box-b text-center" id="b3" >
         X
       </div>
       <br>
<?php
       }
      else if($arr['b3']=='0')
       {
 ?>
      <div class="game-box-c text-center" id="b3" >
         0
      </div>
      <br>
<?php
      }
      // for b4
      if($arr['b4']=='$')
      {
?>

      <div class="game-box-a text-center" id="b4" >
         $
      </div>
<?php        
       }
      else if($arr['b4']=='X') 
       {
?>  
      <div class="game-box-b text-center" id="b4" >
         X
       </div>
<?php
       }
      else if($arr['b4']=='0')
       {
 ?>
      <div class="game-box-c text-center" id="b4" >
         0
      </div>
<?php
      }
      // for b5
      if($arr['b5']=='$')
      {
?>

      <div class="game-box-a text-center" id="b5" >
         $
      </div>
<?php        
       }
      else if($arr['b5']=='X') 
       {
?>  
      <div class="game-box-b text-center" id="b5" >
         X
       </div>
<?php
       }
      else if($arr['b5']=='0')
       {
 ?>
      <div class="game-box-c text-center" id="b5" >
         0
      </div>
<?php
      }
      // for b6
      if($arr['b6']=='$')
      {
?>

      <div class="game-box-a text-center" id="b6" >
         $
      </div>
      <br>
<?php        
       }
      else if($arr['b6']=='X') 
       {
?>  
      <div class="game-box-b text-center" id="b6" >
         X
       </div>
       <br>
<?php
       }
      else if($arr['b6']=='0')
       {
 ?>
      <div class="game-box-c text-center" id="b6" >
         0
      </div>
      <br>
<?php
      }
      // for b7
      if($arr['b7']=='$')
      {
?>

      <div class="game-box-a text-center" id="b7" >
         $
      </div>
<?php        
       }
      else if($arr['b7']=='X') 
       {
?>  
      <div class="game-box-b text-center" id="b7" >
         X
       </div>
<?php
       }
      else if($arr['b7']=='0')
       {
 ?>
      <div class="game-box-c text-center" id="b7" >
         0
      </div>
<?php
      }
      // for b8
      if($arr['b8']=='$')
      {
?>

      <div class="game-box-a text-center" id="b8" >
         $
      </div>
<?php        
       }
      else if($arr['b8']=='X') 
       {
?>  
      <div class="game-box-b text-center" id="b8" >
         X
       </div>
<?php
       }
      else if($arr['b8']=='0')
       {
 ?>
      <div class="game-box-c text-center" id="b8" >
         0
      </div>
<?php
      }
      // for b9
      if($arr['b9']=='$')
      {
?>

      <div class="game-box-a text-center" id="b9" >
         $
      </div>
      <br>
<?php        
       }
      else if($arr['b9']=='X') 
       {
?>  
      <div class="game-box-b text-center" id="b9" >
         X
       </div>
       <br>
<?php
       }
      else if($arr['b9']=='0')
       {
 ?>
      <div class="game-box-c text-center" id="b" >
         0
      </div>
      <br>
<?php
      }


}

?>

<?php

$q3="select ut1,ut2 from playing where tablename='$playingtn' ";
$lstud=mysqli_query($con,$q3);
$lstudindex=mysqli_fetch_array($lstud);

$ut1=$lstudindex['ut1'];
$ut2=$lstudindex['ut2'];
?>

</div> 
 
<div class="col-md-4 mt-5 text-center d-none d-sm-block">
    
<?php

if($id==$ut1)
{
      $qforname="select name from users where id=$ut2";
      $namearr=mysqli_query($con,$qforname);
      $nameindex=mysqli_fetch_array($namearr);
      $name=$nameindex['name'];
?>
      <h3 class="text-center ">Your compititor: </h3>
      <br> <br>
      <h2 class="text-secondary"> <?php echo $name ?> </h2>
<?php
     
}
else{
      $qforname="select name from users where id=$ut1";
      $namearr=mysqli_query($con,$qforname);
      $nameindex=mysqli_fetch_array($namearr);
      $name=$nameindex['name'];
?>
      <h3 class="text-center ">Your compititor: </h3>
      <br> <br>
      <h2 class="text-secondary"> <?php echo $name ?> </h2>
<?php
    
}

?>

</div>



<section class="d-block d-sm-none">

<div class="col-xs-12 col-sm-12">

<?php




if($id==$user_turn)
{
?>
     <br>
      <h3>This is your turn.</h3>
<?php
}
else
{
      if($user_turn==$ut1)
      {
      $qforname="select name from users where id=$ut1";
      $namearr=mysqli_query($con,$qforname);
      $nameindex=mysqli_fetch_array($namearr);
      $name=$nameindex['name'];
?>
      <br>
      <h3 class="text-center" >Wait... <?php echo $name ?> is playing</h3>
<?php
      }
      else{
            $qforname="select name from users where id=$ut2";
            $namearr=mysqli_query($con,$qforname);
            $nameindex=mysqli_fetch_array($namearr);
            $name=$nameindex['name'];
            
?>
       <br>
        <h3 class="text-center" >Wait.. <?php echo $name ?> is playing </h3>
<?php
      }
}


?>


</div>


   
</section>

<?php
}
?>