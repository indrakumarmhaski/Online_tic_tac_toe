<?php

session_start();

if( !isset($_SESSION['username']) || !isset($_SESSION['password']) )
{
    header('location:index.html');
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Game</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
     <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="css/signuppage.css">

</head>
<body>

<div class="container-fluid">

    <header>
            <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
                    <a class="navbar-brand" href="">Tic-Tac-Toe</a>
                    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                      <span class="navbar-toggler-icon"></span>
                    </button>
                  
                    <div class="collapse navbar-collapse" id="navbarSupportedContent">
                      <ul class="navbar-nav ">
                        
                        <li class="nav-item dropdown">
                          <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                            Contect-Us
                          </a>
                          <div class="dropdown-menu" aria-labelledby="navbarDropdown">
                            <a class="dropdown-item" href="">8770734350</a>
                            <div class="dropdown-divider"></div>
                            <a class="dropdown-item" href="">indrakumarmhasi@gmail.com</a>
                          </div>                            
                        </li>
                      </ul>                      
                    </div>
                    
                  </nav>
    </header>



<section class="text-center form-container bg-info">
   
<a type="button" href="deleteconform.php" class="btn bg-warning btn-group-sm signupbtn ">Delete Accoutnt</a>
    <a type="button" href="userpage.php" class="btn bg-warning btn-group-sm signupbtn ">Cencle</a>
    <br>

  <form class=" sm-mt-5" action="updateimage.php" method="post" enctype="multipart/form-data" >
      

    <div class="form">
      
    
    
    <label for="photo" class="leb_photo">Profile Image:</label>
    <input type="file" class="inp_photo" name="image" >
    <br>


    <input type="submit" class="btn btn-group-sm btn-danger mt-3" value="Update">

    
  
   
    
    </div>
    
  </form>
  <br>


</section>
    

<section class="bg-dark text-center pt-5" >

  <div class="col-md-3 mt-2" style="display: inline-block">
      <a href="https://www.linkedin.com/in/indra-kumar-mhaski-15055714a" style="color: rgb(0, 250, 187)"> <i class="fa fa-4x fa-linkedin"></i> </a>
  
  </div>
  <div class="col-md-3 mt-2" style="display: inline-block">
      <a href="https://twitter.com/Indra_Kr_Mhaski" style="color: rgb(0, 250, 187)"> <i class="fa fa-4x fa-twitter"></i> </a>
  </div>

  <div class="col-md-3 mt-2" style="display: inline-block">
      <a href="https://github.com/indrakumarmhaski" style="color: rgb(0, 250, 187)"> <i class="fa fa-4x fa-github"></i> </a>
    </div>
  <div class="col-md-2 mt-2" style="display: inline-block">
        <a href="https://codepen.io/Indra_Kr_Mhaski/" style="color: rgb(0, 250, 187)"> <i class="fa fa-4x fa-codepen"></i> </a>
  </div>
  
</section>


<footer class="footer bg-dark">

    <blockquote class="blockquote text-left">
      
            <p class="text-right pt-3" style="color: rgb(0, 250, 154)">&copy; 2018 Er. Indra Kumar Mhaski.</p>
            <hr>
            <p class="mb-0" style="color: rgb(0, 250, 154)">This site is developed and maintained by:
                <cite title="Source Title">Er.
                    Indra Kumar Mhaski.
                </cite>
            </p>
        </blockquote>

</footer>


</div>
<script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>

</body>
</html>