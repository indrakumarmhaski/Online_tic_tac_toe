<?php

session_start();

$username=$_SESSION['username'];
$password=$_SESSION['password'];

$con=mysqli_connect('localhost','id4760458_indra','Indra@123');
mysqli_select_db($con,'id4760458_ttt');

$q1="select id,smb,playingtn from users where name='$username' and password='$password' ";
$r=mysqli_query($con,$q1);
$rindex=mysqli_fetch_array($r);
$tablename=$rindex['playingtn'];

$ison="update users set isonline=0,smb='*',play_req=0,sender=0,response='no',playingtn='00000' where name='$username' and password='$password' ";
    mysqli_query($con,$ison);

    $q1="select user_turn from playing where tablename='$tablename' ";
    $isexist=mysqli_query($con,$q1);
    $nor=mysqli_num_rows($isexist);
    if($nor==1)
    {  
        $q2="delete from playing where tablename='$tablename' ";
        mysqli_query($con,$q2);
    }
    else
    {   }


    mysqli_close($con);
session_destroy();
header('location:index.html');


?>
