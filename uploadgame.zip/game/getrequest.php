<?php

$senderuser=intval($_GET['senderuser']);

$con=mysqli_connect('localhost','id4760458_indra','Indra@123');
mysqli_select_db($con,'id4760458_ttt');

$q="select play_req,sender from users where id=$senderuser";

$result=mysqli_query($con,$q);

$array=mysqli_fetch_array($result);

if($array['play_req']==1)
{
    $qu="select name from users where id=$senderuser";
    $r=mysqli_query($con,$qu);
    $arr=mysqli_fetch_array($r);
    echo $arr['name'] ;
    echo " Wants to play Tic-Tac-Toe with you, allow?";
}
else
{
    echo '0';
}




mysqli_close($con);

?>