
<?php


    $reseveruser=intval($_GET['reseveruser']);

    $con=mysqli_connect('localhost','id4760458_indra','Indra@123');
    mysqli_select_db($con,'id4760458_ttt');

    $q="update users set response='yes' where id=$reseveruser";
  
    $r=mysqli_query($con,$q);
    
    $qu="select sender from users where id=$reseveruser ";
    $getsender=mysqli_query($con,$qu);
    $senderarr=mysqli_fetch_array($getsender);
    $sender=$senderarr['sender'];
    $tablename=$_GET['reseveruser'].$sender;
    $que="update users set playingtn='$tablename' where id=$reseveruser";
    mysqli_query($con,$que);

    $q1="select user_turn from playing where tablename='$tablename' ";
    $isexist=mysqli_query($con,$q1);
    $nor=mysqli_num_rows($isexist);
    if($nor==1)
     {

     }
    else
     {
         $q2="insert into playing (tablename) values ('$tablename') ";
         mysqli_query($con,$q2);
     }
  
mysqli_close($con);

      echo 'done';
?>