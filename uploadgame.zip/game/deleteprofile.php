<?php

session_start();

if( !isset($_SESSION['username']) || !isset($_SESSION['password']) )
{
    header('location:index.html');
}

$con=mysqli_connect('localhost','id4760458_indra','Indra@123');
mysqli_select_db($con,'id4760458_ttt');

$username=$_SESSION['username'];
$password=$_SESSION['password'];

$q="delete from users where name='$username' and password='$password' ";

mysqli_query($con,$q);

mysqli_close($con);

session_destroy();

header('location:index.html');


?>