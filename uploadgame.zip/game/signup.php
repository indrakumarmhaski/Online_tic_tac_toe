<?php

$username=$_POST['username'];
$password=$_POST['password'];
$photo=$_FILES['photo']['tmp_name'];

$con=mysqli_connect('localhost','id4760458_indra','Indra@123');
mysqli_select_db($con,'id4760458_ttt');
$q="select name,password from users where name='$username' and password='$password' ";
$result=mysqli_query($con,$q);
$num=mysqli_num_rows($result);
if($num==1)
{
    header('location:upexists.php');
}
else
{
    if($_FILES['photo']['type'] != "image/jpeg")
    {
        header('location:notjpeg.php');
    }
    else
    {
        $imageContent=addslashes(file_get_contents($photo));
        $query="insert into users (name,password,photo) values ('$username','$password','$imageContent')";
        $re=mysqli_query($con,$query);
        if($re==1)
        {
            header('location:conform.php');
        }
        else
        {
            header('location:error.php');
        }
    }
}

mysqli_close($con);



?>