<?php

session_start();

$username=$_SESSION['username'];
$password=$_SESSION['password'];

$con=mysqli_connect('localhost','id4760458_indra','Indra@123');
mysqli_select_db($con,'id4760458_ttt');
?>

<h3 class="text-center">All Users</h3>

<?php
$query="select name,isonline,password,id from users order by name";
$result=mysqli_query($con,$query);
$num=mysqli_num_rows($result);
?>
<ol>
<?php
for($i=1;$i<=$num;$i++)
{
$arr=mysqli_fetch_array($result);
?>
 <h3>
    
           <?php
           if($username!=$arr['name'] && $password!=$arr['password'])
           {
           ?>
            <li>
           <?php
             echo $arr['name'];
             
             if($arr['isonline']==1)
               {
                   
               ?>
                   <button id="<?php echo $arr['id'] ?>" onclick="req('<?php echo $id ?>','<?php echo $arr['id']?>')" type="button" class="btn btn-success">Request</button>
           <?php    
               }
             else
               {
               ?>
                   <button type="button" class="btn btn-success disabled">Offline</button>
               <?php
               }
           ?>
            </li>
            <hr>
           <?php
           }
           ?>
    

 </h3>

<?php
}
?>
</ol>

  