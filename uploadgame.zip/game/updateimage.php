<?php
// Php logic to add a user 
// Mainly intrection with db.
session_start();
$username=$_SESSION['username'];
$password=$_SESSION['password'];
$photo=$_FILES['image']['tmp_name'];
$size=$_FILES['image']['size'];

// Check That the image should be in jpeg formet.
if($_FILES['image']['type'] != "image/jpeg")
  {
      header('location:maxsize.php');
  }
else if($size>500000)
{
      header('location:maxsize.php');
}
else
{
$imageContent=addslashes(file_get_contents($photo));

//Stablish connection
$con=mysqli_connect('localhost','id4760458_indra','Indra@123');
mysqli_select_db($con,'id4760458_ttt');
     $q="update users set photo='$imageContent'  where name='$username' and password='$password'";
     $r=mysqli_query($con,$q);
     if($r==1)
         {
          //  If everything is all right then the account will be created and you will 
          // be thro to conform.php page where you will be redirected to the login page 
          // where you can log in.
             header('location:userpage.php');
         }
       else
        {
          // If some errow occors then you will be thrown to that page
             header('location:userpage.php');
         }
   
}
mysqli_close($con);
?>