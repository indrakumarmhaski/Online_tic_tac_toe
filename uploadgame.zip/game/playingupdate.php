<?php

session_start();

$username=$_SESSION['username'];
$password=$_SESSION['password'];

$boxname=$_GET['boxid'];

$con=mysqli_connect('localhost','id4760458_indra','Indra@123');
mysqli_select_db($con,'id4760458_ttt');
$q1="select id,smb,playingtn from users where name='$username' and password='$password' ";
$r=mysqli_query($con,$q1);
$rindex=mysqli_fetch_array($r);
$id=$rindex['id'];
$smb=$rindex['smb'];
$playingtn=$rindex['playingtn'];




$q="select smb from users where id=$id ";
$smb=mysqli_query($con,$q);
$smbindex=mysqli_fetch_array($smb);
$simbol=$smbindex['smb'];

$q1="update playing set $boxname='$simbol' where tablename='$playingtn' ";
mysqli_query($con,$q1);

$q3="select isupdated,user_turn,ut1,ut2 from playing where tablename='$playingtn' ";
$lstud=mysqli_query($con,$q3);
$lstudindex=mysqli_fetch_array($lstud);
$lastupdate=$lstudindex['isupdated'];
$user_turn=$lstudindex['user_turn'];
$ut1=$lstudindex['ut1'];
$ut2=$lstudindex['ut2'];
$lastupdate=$lastupdate+1;
$q3="update playing set isupdated=$lastupdate where tablename='$playingtn' ";
mysqli_query($con,$q3);


if($user_turn==$ut1)
{
    $q5="update playing set user_turn=$ut2 where tablename='$playingtn' ";
    mysqli_query($con,$q5);
}
else
{
    $q6="update playing set user_turn=$ut1 where tablename='$playingtn' ";
    mysqli_query($con,$q6);
}





mysqli_close($con);






?>

